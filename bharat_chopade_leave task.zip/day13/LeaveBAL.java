package day13;

import java.util.List;

public class LeaveBAL {

	static StringBuilder sb = new StringBuilder();
	
	
	public String deleteLeaveBal(int sno) {
		return new LeaveDAO().deleteLeaveDao(sno);
	}
	public Leave searchLeaveBal(int sno) {
		return new LeaveDAO().searchLeaveDao(sno);
	}
	
	public String updateLeaveBal(Leave leave) throws LeaveException {
		LeaveDAO dao = new LeaveDAO();
		if (validateLeave(leave)==true) {
			return dao.updateLeaveDao(leave);
		} else {
			throw new LeaveException(sb.toString());
		}
	}
	public String addLeaveBal(Leave leave) throws LeaveException {
		LeaveDAO dao = new LeaveDAO();
		if (validateLeave(leave)==true) {
			return dao.addLeaveDao(leave);
		} else {
			throw new LeaveException(sb.toString());
		}
	}
	
	public List<Leave> showLeaveBal() {
		return new LeaveDAO().showLeaveDao();
	}
	
	public boolean validateLeave(Leave leave) {
		boolean isAdded=true;
		
		return isAdded;
	}
}
