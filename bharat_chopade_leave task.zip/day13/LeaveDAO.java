package day13;

import java.util.ArrayList;
import java.util.List;

public class LeaveDAO {

	static List<Leave> leaveList;
	
	static {
		leaveList = new ArrayList<Leave>();
	}
	
	public String updateLeaveDao(Leave leaveNew) {
		Leave old = searchLeaveDao(leaveNew.getLeaveId());
		if (old!=null) {
			old.setLeaveId(leaveNew.getLeaveId());
			old.setLeaveStartDate(leaveNew.getLeaveStartDate());
		    old.setLeaveEndDate(leaveNew.getLeaveEndDate());
		    old.setEmpId(leaveNew.getEmpId());
		    old.setNoOfDAys(leaveNew.getNoOfDAys());
		    old.setLeaveAppliedOn(leaveNew.getLeaveAppliedOn());
		    old.setLeaveReason(leaveNew.getLeaveReason());
		
			
			return "Leave Record Updated...";
		}
		return "Leave Record Not Found...";
	}
	public String deleteLeaveDao(int sno ) {
		Leave leave = searchLeaveDao(sno);
		if (leave!=null) {
			leaveList.remove(leave);
			return "Leave Record Deleted...";
		} else {
			return "Leave Record Not Found...";
		}
	}
	public Leave searchLeaveDao(int sno) {
		Leave leave = null;
		for (Leave s : leaveList) {
			if (s.getLeaveId()==sno) {
				leave = s;
			}
		}
		return leave;
	}
	
	public String addLeaveDao(Leave leave) {
		long ms = leave.getLeaveEndDate().getTime() -
                leave.getLeaveStartDate().getTime();
           long m = ms / (1000 * 24 * 60 * 60);
           int days = (int) m;
           days = days + 1;
           leave.setNoOfDAys(days);
		
		leaveList.add(leave);
		return "Leave Record Inserted Successfully...";
	}
	
	public List<Leave> showLeaveDao() {
		return leaveList;
	}
}
