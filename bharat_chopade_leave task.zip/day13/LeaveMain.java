package day13;

import java.util.Date;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

public class LeaveMain  implements Serializable{

	static Scanner sc = new Scanner(System.in);
	
	public static void deleteLeave() {
		System.out.println("Enter  leave id  No    ");
		int sno = sc.nextInt();
		LeaveBAL bal = new LeaveBAL();
		System.out.println(bal.deleteLeaveBal(sno));
	}
	
	public static void searchLeave() {
		System.out.println("Enter leave id No    ");
		int sno = sc.nextInt();
		LeaveBAL bal = new LeaveBAL();
	     Leave leave=bal.searchLeaveBal(sno);
		if (leave !=null) {
			System.out.println(leave);
		}
		else {
			System.out.println("no record");
		}
		
	}
	public static void addLeave() throws LeaveException {
		Leave leave = new Leave();
		System.out.println("Enter Leave id  ");
		leave.setLeaveId(sc.nextInt());
		
		
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Leave Start Date(yyyy-MM-dd)  ");
        try {
            leave.setLeaveStartDate(sdf.parse(sc.next()));
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Enter Leave End Date(yyyy-MM-dd)  ");
        try {
            leave.setLeaveEndDate(sdf.parse(sc.next()));
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Enter empid");
        leave.setEmpId(sc.nextInt());
        
        leave.setLeaveAppliedOn(new Date());
        System.out.println(" enter leave Reason");
        leave.setLeaveReason(sc.next());
        LeaveBAL bal = new LeaveBAL();
        System.out.println(bal.addLeaveBal(leave));
       
        
    }


	public static void updateLeave() throws LeaveException {
		Leave leave = new Leave();
		System.out.println("Enter Leave id  ");
		leave.setLeaveId(sc.nextInt());
		
		
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Leave Start Date(yyyy-MM-dd)  ");
        try {
            leave.setLeaveStartDate(sdf.parse(sc.next()));
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Enter Leave End Date(yyyy-MM-dd)  ");
        try {
            leave.setLeaveEndDate(sdf.parse(sc.next()));
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Enter empid");
        leave.setEmpId(sc.nextInt());
        
        leave.setLeaveAppliedOn(new Date());
        System.out.println(" enter leave Reason");
        leave.setLeaveReason(sc.next());
		
		LeaveBAL bal=new LeaveBAL();
		
		System.out.println(bal.updateLeaveBal(leave));
	}

	public static void showLeave() {
		List<Leave> leaveList = new LeaveDAO().showLeaveDao();
		for (Leave leave : leaveList) {
			System.out.println(leave);
		}
	}
	
	public static void main(String[] args) {
		int choice=0;
		do {
			System.out.println("O P T I O N S");
			System.out.println("--------------");
			System.out.println("1. Add Leave ");
			System.out.println("2. Show Leave ");
			System.out.println("3. Search Leave ");
			System.out.println("4. Delete Leave ");
			System.out.println("5. Update Leave ");
			System.out.println("6. Exit");
			System.out.println("Enter Your Choice  ");
			choice=sc.nextInt();
			switch(choice) {
			case 1 :
				try {
					addLeave();
				} catch ( LeaveException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2 :
				showLeave();
				break;
			case 3 : 
				searchLeave();
				break;
			case 4 :
				deleteLeave();
				break;
			case 5 : 
				try {
					updateLeave();
				} catch (LeaveException e) {
					e.printStackTrace();
				}
				break;
			case 6 : 
				return;
			}
		}while(choice!=6);
	}
}
