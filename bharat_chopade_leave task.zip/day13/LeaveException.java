package day13;

public class LeaveException extends Exception {
	LeaveException() {
		
	}
	LeaveException(String error){
		super(error);
	}

}
